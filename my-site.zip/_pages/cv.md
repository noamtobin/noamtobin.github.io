---
title: "Curriculum Vitae"
permalink: /cv/
---

Please find my CV below. You may also download a copy for your reference.

<a href="/assets/cv.pdf" class="btn btn--success" download>Download CV (PDF)</a>

<br><br>

<iframe src="/assets/cv.pdf" width="100%" height="800px" style="border: none;">
  <p>Your browser does not support PDFs. <a href="/assets/cv.pdf">Download the PDF</a> instead.</p>
</iframe>
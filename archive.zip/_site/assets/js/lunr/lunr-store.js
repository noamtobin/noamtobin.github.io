var store = [{
        "title": "Stochastic Control and Levy Processes for Systematic Trading",
        "excerpt":"In systematic decision making in quantitative finance, stochastic optimal control offers a powerful framework for capturing market randomness and the progressive revelation of information. Lévy processes—stochastic models with stationary, independent increments—provide a unified approach to modeling evolving quantities such as asset prices and insurance claim sizes. Under the guiding supervision...","categories": [],
        "tags": [],
        "url": "/Stochastic-Control-and-Levy-Frameworks-in-Quantitative-Finance/",
        "teaser": null
      }]
